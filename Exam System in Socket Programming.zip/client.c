#include<sys/types.h>
#include<stdio.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<netinet/ip.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<stdlib.h>

#define SIZE 1024

void write_file(int sockfd){
	//creating file
	int n;
	char buffer[SIZE];
	FILE *fptr;
	char *filename = "paper_rec.txt";

	fptr = fopen(filename, "w");

	while(1){
		n = recv(sockfd, buffer, SIZE, 0);
		if(n <= 0){
			break;
			return;
		}
		fprintf(fptr, "%s", buffer);
		//printf("*What we got %s\n", buffer);
		bzero(buffer, SIZE);
	}
	return;
}

void send_file(int sockfd, char *filename){
	FILE *fptr;
	//char *filename = "paper_rec.txt";
	fptr = fopen(filename, "r");
	if(fptr == NULL){
		perror("Fail to read file");
		exit(1);
	}
	
	int n;
	char data[SIZE] = {0};

	while(fgets(data, SIZE, fptr) != NULL){
		if(send(sockfd, data, sizeof(data), 0) == -1){
			perror("Error in sending file1");
			exit(1);
		}
		//printf("CLIENT:: *What we got %s\n", data);
		bzero(data, SIZE);
	}
}

int connectToServer(){
	int sockfd = -1, ret = -1;
	struct sockaddr_in serverAddr;

	char buff[50];
	char *filename;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd < 0){
		perror("socket fail \n");
		return -1;
	}

	printf("CLIENT:: socket created\n");

	//serverAddr in sockaddr structure
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(9876);	
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");


	ret = connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		perror("CLIENT:: Connect faile\n");
		close(sockfd);
		return -1;
	}	

	printf("CLIENT:: Connection is established\n");
	printf("CLIENT:: ready to communicate\n");

	//printf("\n Press Enter to Receive Question Paper \n");
	//getchar();	//take keyboard input before execiting next lines	

	//communicate with server
	char option;
	printf("Enter R/r to recv question paper or S/s to upload answers: \n");
	
	do{
		scanf("%c", &option);
		printf("%c", option);
	}while(option != 'r' && option != 's');


	strncpy(buff, &option, sizeof(buff));	
	write(sockfd, buff, strlen(buff)+1);
	printf("CLIENT:: data written to server\n");    

	if(option == 'r'){
		char rbuf[50];
		//Service the client or communicate with client 
		read(sockfd, rbuf ,sizeof(rbuf));

		//Error handling: Error msg send by server are starts from '*'	
		if(rbuf[0] == '*'){		
			printf("\nERROR: \t\t%s\n", rbuf);
			exit(1);		
		}
		/*********/
	
		write_file(sockfd);


	}
	else if(option == 's'){
		printf("\n...submitting file to server.........\n");
		char rbuf[50];
		//Service the client or communicate with client 
		read(sockfd, rbuf ,sizeof(rbuf));
		printf("CLINET:: data from server: %s\n", rbuf);
		

		printf("Enter .txt file name: ");
		scanf("%s", filename);
		printf("Entered Name: %s\n", filename);
		

		//Error handling: Error msg send by server are starts from '*'	
		if(rbuf[0] == '*'){
			printf("\nERROR: %s\n", rbuf);
			exit(1);		
		}
		/****/

		send_file(sockfd, filename);
	}
	


	memset(buff, '\0', sizeof(buff));


	printf("CLIENT:: communication compelted...closing connection\n");
	close(sockfd); 

	return 0;
}


int main(){

	int x;

	connectToServer();
	printf("Connection Finish\n");

	return 0;	
}
