#include<sys/types.h>
#include<stdio.h>
#include<sys/socket.h>
#include<string.h>
#include<netinet/in.h>
#include<netinet/ip.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/wait.h>
#include<signal.h>
#include<stdlib.h>
#include<time.h>

#define SIZE 1024
#define TEMP_FAILURE_RETRY


void SigHandler(int signum)
{
	//need to collect the exit status of the terminated child process	
	int status;
	wait(&status);
	//printf("Inside SIGCHILD handler and the exit status is %d\n", status);
	printf("..............................................\n");
	return;
}


void send_file(int sockfd){
	//picking up file
	char fileBuff[SIZE];
	FILE *fptr;
	char *filename = "paper.txt";
	fptr = fopen(filename, "r");
	if(fptr == NULL){
		perror("FILE:: Can't open file\n");
		exit(1);
	}


	int n;
	char data[SIZE] = {0};

	while(fgets(data, SIZE, fptr) != NULL){
		if(send(sockfd, data, sizeof(data), 0) == -1){
			perror("Error in sending file1");
			exit(1);
		}
		bzero(data, SIZE);
	}
}

//char *num = "1";

void write_file(int sockfd){
	int num = 1;
	//getting numbers of stored files 
	FILE *dataptr;
	dataptr = fopen("filedata.txt", "r");
	if(dataptr == NULL){
		perror("Can't open data file");
		exit(1);
	}
	fscanf(dataptr, "%d", &num);

	//creating file
	int n;
	char buffer[SIZE];
	FILE *fptr;

	char filename[20];
	char word = num + '0';
	strcpy(filename, "Student File ");
	strcat(filename, &word);
	strcat(filename, ".txt");
	num = num + 1;
	//printf("num: %d", num);

	//saving numbers of files stored
	dataptr = fopen("filedata.txt", "w");
	if(dataptr == NULL){
		perror("Can't open data file");
		exit(1);
	}
	fprintf(dataptr, "%d", num);

	//printf("word: %c", word);
	//printf("FILENAME: %s", filename);

	fptr = fopen(filename, "w");
	while(1){
		n = recv(sockfd, buffer, SIZE, 0);
		if(n <= 0){
			break;
			return;
		}
		fprintf(fptr,"%s",buffer);
		bzero(buffer, SIZE);
	}
	printf("SERVER:: ANS RECV\n");
	return;
}

double calculateTime(time_t begin){
	time_t end = time(NULL);
	printf("Time %ld sec: \n", (end - begin));
	return (end - begin);
}

time_t time_limit = 300;	//5mint
time_t sub_time = 360;		//6mint

int main()
{
	time_t begin = time(NULL);
	time_t TIME;
	int count = 0;

	int sockfd = -1, ret = -1, sessfd = -1, len = -1;
	int pid = -1;
	char rbuf[50];
	struct sockaddr_in serverAddr, clientAddr;


	//socket creation
	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd < 0){
		perror("Socket() failed\n");
		return -1;
	}

	printf("Socket created successfully\n");

	//name the socket or provide the address using bind() call
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(9876);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");	//IP addr

	ret = bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		perror("bind() fail\n");
		close(sockfd);
		return -1;
	}

	printf("Bind Success with %s:%d\n", inet_ntoa(serverAddr.sin_addr), ntohs(serverAddr.sin_port));

	//listening for client connection request
	ret = listen(sockfd, 5);
	if(ret < 0){
		perror("Listen Failed \n");
		close(sockfd);
		return -1;
	}

	printf("Server:: Listening for new connection \n");
	printf("..........................................\n");
	printf("SERVER:: parent process id is %d\n", getpid());

	len = sizeof(clientAddr);
	
	//registering the signal handler for SIGCHILD signal
	signal(SIGCHLD, SigHandler);
	//whenever SIGCHLD is received by parent, it suspends actual flow of execution and  ,it calls signhandler function and then resumes its normal flow

	
	int flage = 0;
	while(1) {

		flage = 1;
		TIME = calculateTime(begin);
		//accepting a client request and creating a session(sessfd) socket for this lient	
		sessfd = accept(sockfd, (struct sockaddr*)&clientAddr, &len);	
		if(sessfd < 0){
			perror("accept fail \n");
			close(sockfd);
			return -1; 
		}

		printf("client request accepted from %s:%d\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));

		//creating child process for servicing newly connected client
		pid = fork();	
		if(pid > 0){	//parent process
			//parent is responsble for listening and accepting of new connection
			//parent never services the client. so close sessfd
			close(sessfd);
			continue; //continue with next client		
		}
		else if(pid == 0){ //child process
			printf("CHILD:: pid %d ppid %d\n", getpid(), getppid());

			

			//reposible for servcing the client. No need of listen. so close sockfd.
			//close(sockfd);
			
		
			//Service the client or communicate with client 
			read(sessfd, rbuf ,sizeof(rbuf));
			printf("Server:: data from client: %s\n", rbuf);	


			
			

			if(rbuf[0] == 'r'){
				printf("\n 	 ****R/r: Sending file to client***   \n");
				
			/* Checking Time Limit */
			time_t end = time(NULL);
			time_t timeChk = (end - begin);
			printf("*Time = %ld\n", timeChk);
			if(timeChk >= time_limit){
				printf("\n	**File Sending Time is Over**	\n");
				strncpy(rbuf, "**Time for receiving Question Paper is over**", sizeof(rbuf));
				write(sessfd, rbuf, strlen(rbuf)+1);
				return -1;
			}
			/****/
				

			//sending file
			send_file(sessfd);
			printf("FILE SENT\n");		

			//communicatioon complete
			close(sessfd);	
			printf("Session socket is closed\n");
			printf("Terminating Child %d\n", getpid());

			printf("..........................................\n");

			_exit(0); //terminating child process		
			//OS automatically generates SIGCHLD signal and snds it to the parent process



			}else if(rbuf[0] == 's') {
				printf(" 	\n ****S/s: Recving file from client***   \n");
				//send msg to client
				strncpy(rbuf, "ACK from Server", sizeof(rbuf));
				write(sessfd, rbuf, strlen(rbuf)+1);
				printf("SERVER:: data sent to client\n");

				/*	Checking Time	*/
				time_t end = time(NULL);
				time_t timeChk = (end - begin);	
				if(timeChk >= sub_time){
					printf("\n	**File Receiving Time is over**	\n");
					strncpy(rbuf, "**Submission Time is Over!**", sizeof(rbuf));
					write(sessfd, rbuf, strlen(rbuf)+1);
					return -1;
				}			
			
				write_file(sessfd);
				break;

						

			}else{
	
			}
				

			//communicatioon complete
			close(sessfd);	
			printf("Session socket is closed\n");
			printf("Terminating Child %d\n", getpid());

			printf("..........................................\n");

			_exit(0); //terminating child process		
			//OS automatically generates SIGCHLD signal and snds it to the parent process

		}
		else if(pid < 0){
			perror("fork failed\n");
			//implement according to the requirment.
			continue;
		}
	
	
	
	}//end of while

	close(sockfd);
	printf("Close the main socket\n");

	return 0;
}








